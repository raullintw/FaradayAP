﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Vuforia;

public class VButtonManager : MonoBehaviour, IVirtualButtonEventHandler
{
	public GameObject DayOne;
	public GameObject DayTwo;

    // Start is called before the first frame update
    void Start()
    {
        GetComponent<VirtualButtonBehaviour>().RegisterEventHandler(this);
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void OnButtonPressed(VirtualButtonBehaviour vb)
    {
        Debug.Log("OnButtonPressed", gameObject);
		DayOne.gameObject.transform.localScale = new Vector3(0,0,0);
		DayTwo.gameObject.transform.localScale = new Vector3(0.1F,0.1F,0.1F);
		//DayTwo.GetComponent<Transform>().LocalScale(new Vector3(0.1,0.1,0.1));
        //DayTwo.GetComponent<Transform>().Rotate(new Vector3(0,50));
        //throw new System.NotImplementedException();
    }

    public void OnButtonReleased(VirtualButtonBehaviour vb)
    {
        Debug.Log("OnButtonReleased", gameObject);
		DayOne.gameObject.transform.localScale = new Vector3(0.1F,0.1F,0.1F);
		DayTwo.gameObject.transform.localScale = new Vector3(0,0,0);
        //throw new System.NotImplementedException();
    }
}