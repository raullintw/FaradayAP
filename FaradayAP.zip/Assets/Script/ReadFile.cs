﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ReadFile : MonoBehaviour {

	public TextAsset textFile;
	public int layoutHeight;
    public int index = 0;

	private GameObject clonePanel;
	private string[] days;
    private Vector2 panelSize;
    private Vector2 titlePanelSize;
    private float cellHeight;

    private Transform verticalLayout;
    private GameObject titlePanel;
    private GameObject datePanel;

    private int count = 0;

	// Use this for initialization
	void Start () {
		days = textFile.text.Split(char.Parse("\n"));
		clonePanel = transform.GetChild(0).gameObject;

		string[] items = days[0].Split(char.Parse("@"));

        cellHeight = (float)(layoutHeight / (items.Length / 2 + 1));
        titlePanelSize = new Vector2(200, cellHeight);
        verticalLayout = gameObject.transform.parent.GetChild(0);

        transform.localPosition = new Vector3(0, -cellHeight, 0);
        verticalLayout.localPosition = new Vector3(0, layoutHeight / 2 - cellHeight, 0);
        transform.GetComponent<RectTransform>().sizeDelta = new Vector2(200, layoutHeight - cellHeight * 2);
        verticalLayout.GetComponent<RectTransform>().sizeDelta = new Vector2(200, cellHeight * 2);

        titlePanel = Instantiate(clonePanel) as GameObject;
        datePanel = Instantiate(clonePanel) as GameObject;
        titlePanel.transform.parent = verticalLayout;
        datePanel.transform.parent = verticalLayout;
        titlePanel.GetComponent<RectTransform>().sizeDelta = titlePanelSize;
        datePanel.GetComponent<RectTransform>().sizeDelta = titlePanelSize;
        titlePanel.transform.GetChild(0).gameObject.GetComponent<Text>().text = items[0];
        datePanel.transform.GetChild(0).gameObject.GetComponent<Text>().text = items[1];


        panelSize = new Vector2(100, cellHeight);
        gameObject.GetComponent<GridLayoutGroup>().cellSize = panelSize;

        clonePanel.transform.GetChild(0).gameObject.GetComponent<Text>().text = items[2];

		for (int i = 3; i < items.Length; i++)
		{
			GameObject panel = Instantiate(clonePanel) as GameObject;
			panel.transform.parent = gameObject.transform;
			panel.transform.GetChild(0).gameObject.GetComponent<Text>().text = items[i];
		}

	}

	// Update is called once per frame
	void Update () {
		count++;
		if (count != 200) return;

  //      index++;

        for (int i = 1; i < transform.childCount; i++)
		{
			Destroy(transform.GetChild(i).gameObject);
		}

        string[] items = days[index].Split(char.Parse("@"));

        cellHeight = (float)(layoutHeight / (items.Length / 2 + 1));
        titlePanelSize = new Vector2(200, cellHeight);
        titlePanel.GetComponent<RectTransform>().sizeDelta = titlePanelSize;
        datePanel.GetComponent<RectTransform>().sizeDelta = titlePanelSize;
        datePanel.transform.GetChild(0).gameObject.GetComponent<Text>().text = items[1];

        transform.localPosition = new Vector3(0, -cellHeight, 0);
        verticalLayout.localPosition = new Vector3(0, layoutHeight / 2 - cellHeight, 0);
        transform.GetComponent<RectTransform>().sizeDelta = new Vector2(200, layoutHeight - cellHeight * 2);
        verticalLayout.GetComponent<RectTransform>().sizeDelta = new Vector2(200, cellHeight * 2);

        panelSize = new Vector2(100, cellHeight);
        gameObject.GetComponent<GridLayoutGroup>().cellSize = panelSize;

        clonePanel.transform.GetChild(0).gameObject.GetComponent<Text>().text = items[2];

		for (int i = 3; i < items.Length; i++)
		{
			GameObject panel = Instantiate(clonePanel) as GameObject;
			panel.transform.parent = gameObject.transform;
			panel.transform.GetChild(0).gameObject.GetComponent<Text>().text = items[i];
		}
	}
}